# Data Directory

Raw data files are **not** committed to this repository (see `.gitignore`). This keeps the repository lightweight and respects each dataset's original license/terms of use on its hosting platform.

## Candidate Public Datasets (Week 1 Research)

1. **Amazon Delivery Dataset**
   Source: Kaggle — `https://www.kaggle.com/datasets/sujalsuthar/amazon-delivery-dataset`
   ~13,000 last-mile delivery records with order/pickup timestamps, weather, traffic, and delivery outcomes.

2. **DataCo Smart Supply Chain for Big Data Analysis**
   Source: Kaggle — `https://www.kaggle.com/datasets/shashwatwork/dataco-smart-supply-chain-for-big-data-analysis`
   18,000+ order records with 50+ features covering shipping, delivery status, and regional/customer data.

3. **Daily Demand Forecasting Orders**
   Source: UCI Machine Learning Repository — `https://archive.ics.uci.edu/ml/datasets/Daily+Demand+Forecasting+Orders`
   Real 60-day order-volume dataset from a Brazilian logistics company.

## How to Add Data Locally

1. Download the chosen dataset from its source above (a free Kaggle account may be required).
2. Place the CSV file in this `data/` folder, e.g. `data/logistics_data.csv`.
3. Do not commit raw data files to Git — they are excluded via `.gitignore`.
4. Update `src/data_loading.py` if your column names differ from the placeholder schema used in this project's code.

## Expected Schema (Placeholder)

The example scripts in `src/` and the code in the Week 1 report assume a schema similar to:

`order_id, customer_id, order_date, expected_delivery_date, delivery_date, distance_km, order_quantity, vehicle_id, vehicle_type, vehicle_capacity, delivery_cost, traffic_condition, weather_condition, delivery_status`

Adjust column names in the scripts to match whichever dataset you select.
